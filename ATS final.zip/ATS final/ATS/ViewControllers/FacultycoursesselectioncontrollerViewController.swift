import UIKit


class FacultycoursesselectioncontrollerViewController: UIViewController, Storyboarded, UITableViewDataSource, UITableViewDelegate{
    
    let courseArray = ["GDP","Java","PM","iOS","Android","Data Bases"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return courseArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = courseTableView.dequeueReusableCell(withIdentifier: "courseCell",for: indexPath)
        cell.textLabel?.text = courseArray[indexPath.row]
        return cell
    }
    
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var coursesLabel: UILabel!
	@IBOutlet private weak var line1ImageView: UIImageView!
	@IBOutlet private weak var borderView: UIView!
	@IBOutlet private weak var vectorsImageView: UIImageView!
    
    
    @IBOutlet weak var courseTableView: UITableView!
    
	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
        courseTableView.dataSource = self
        courseTableView.delegate = self
	}

}

extension FacultycoursesselectioncontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyselectioncontroller), for: .touchUpInside)

		logoutButton.setImage(UIImage(named: "logout") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)

		coursesLabel.textColor = UIColor.daisy
		coursesLabel.numberOfLines = 0
		coursesLabel.font = UIFont.textStyle6
		coursesLabel.textAlignment = .center
		coursesLabel.text = NSLocalizedString("courses", comment: "")


		/*rectangleView.layer.cornerRadius = 10
		rectangleView.layer.masksToBounds =  true
		rectangleView.backgroundColor = UIColor.spruce*/


		borderView.layer.borderColor = UIColor.cerulean.cgColor
		borderView.layer.borderWidth =  1
		borderView.layer.cornerRadius = 8
		borderView.layer.masksToBounds =  true

        courseTableView.backgroundColor = UIColor.lightGray
        

	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

