import UIKit

class LoginstudentcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var loginLabel3: UILabel!
	@IBOutlet private weak var loginTextField: UITextField!
	@IBOutlet private weak var passwordTextField: UITextField!
	@IBOutlet private weak var forgotPasswordButton: UIButton!
	@IBOutlet private weak var loginPageButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension LoginstudentcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudenthomepagecontroller), for: .touchUpInside)

		loginLabel3.textColor = UIColor.daisy
		loginLabel3.numberOfLines = 0
		loginLabel3.font = UIFont.textStyle4
		loginLabel3.textAlignment = .center
		loginLabel3.text = NSLocalizedString("login2", comment: "")

		loginTextField.layer.cornerRadius = 10
		loginTextField.layer.masksToBounds =  true
		loginTextField.backgroundColor = UIColor.white
		loginTextField.textColor = UIColor.daisy
		loginTextField.font = UIFont.textStyle3
		loginTextField.textAlignment = .center
		loginTextField.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 18, height: 45))

		loginTextField.placeholder = NSLocalizedString("login2", comment: "")


		passwordTextField.layer.cornerRadius = 10
		passwordTextField.layer.masksToBounds =  true
		passwordTextField.backgroundColor = UIColor.white
		passwordTextField.textColor = UIColor.daisy
		passwordTextField.font = UIFont.textStyle3
		passwordTextField.textAlignment = .center
		passwordTextField.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 21, height: 45))

		passwordTextField.placeholder = NSLocalizedString("password", comment: "")


		forgotPasswordButton.setTitleColor(UIColor.seafoam, for: .normal)
		forgotPasswordButton.titleLabel?.font = UIFont.textStyle
		forgotPasswordButton.contentHorizontalAlignment = .center 

		forgotPasswordButton.setTitle(NSLocalizedString("forgot.password", comment: ""),for: .normal)


		loginPageButton.layer.cornerRadius = 10
		loginPageButton.layer.masksToBounds =  true
		loginPageButton.backgroundColor = UIColor.slate
		loginPageButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		loginPageButton.setTitleColor(UIColor.daisy, for: .normal)
		loginPageButton.titleLabel?.font = UIFont.textStyle2
		loginPageButton.contentHorizontalAlignment = .center 
		loginPageButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 17 , bottom: 13, right: 17)

		loginPageButton.setTitle(NSLocalizedString("login", comment: ""),for: .normal)

		loginPageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudentselectioncontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

