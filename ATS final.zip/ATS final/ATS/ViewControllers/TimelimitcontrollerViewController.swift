import UIKit

class TimelimitcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var _view: UIView!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var facultyHomePage: UIButton!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var selectTimeLimitLabel: UILabel!
	@IBOutlet private weak var line1ImageView: UIImageView!
	@IBOutlet private weak var rectangleView: UIView!
	@IBOutlet private weak var rectangleView2: UIView!
	@IBOutlet private weak var minutesLabel: UILabel!
	@IBOutlet private weak var minutesLabel2: UILabel!
	@IBOutlet private weak var rectangleView3: UIView!
	@IBOutlet private weak var rectangleView4: UIView!
	@IBOutlet private weak var minutesLabel3: UILabel!
	@IBOutlet private weak var noTimeLimitLabel: UILabel!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension TimelimitcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		_view.layer.cornerRadius = 22
		_view.layer.masksToBounds =  true
		_view.backgroundColor = UIColor.smoke
		_view.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.1599999964237213,
		                    x: 4,
		                    y: 4,
		                    blur: 17,
		                    spread: 0)
		_view.addShadow(color: UIColor(red:0.9166666865348816, green: 0.9166666865348816, blue: 0.9166666865348816, alpha: 1),
		                    alpha: 0.07999999821186066,
		                    x: -4,
		                    y: -4,
		                    blur: 17,
		                    spread: 0)


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openQrcontroller), for: .touchUpInside)

		facultyHomePage.setImage(UIImage(named: "vector2") , for: .normal)

		facultyHomePage.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyselectioncontroller), for: .touchUpInside)

		logoutButton.setImage(UIImage(named: "logoutButton") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)

		selectTimeLimitLabel.textColor = UIColor.daisy
		selectTimeLimitLabel.numberOfLines = 0
		selectTimeLimitLabel.font = UIFont.textStyle6
		selectTimeLimitLabel.textAlignment = .center
		selectTimeLimitLabel.text = NSLocalizedString("select.time.limit", comment: "")


		rectangleView.layer.cornerRadius = 10
		rectangleView.layer.masksToBounds =  true
		rectangleView.backgroundColor = UIColor.seafoam
		rectangleView.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)


		rectangleView2.layer.cornerRadius = 10
		rectangleView2.layer.masksToBounds =  true
		rectangleView2.backgroundColor = UIColor.seafoam
		rectangleView2.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)


		minutesLabel.textColor = UIColor.daisy
		minutesLabel.numberOfLines = 0
		minutesLabel.font = UIFont.textStyle3
		minutesLabel.textAlignment = .center
		minutesLabel.text = NSLocalizedString(".minutes", comment: "")

		minutesLabel2.textColor = UIColor.daisy
		minutesLabel2.numberOfLines = 0
		minutesLabel2.font = UIFont.textStyle3
		minutesLabel2.textAlignment = .center
		minutesLabel2.text = NSLocalizedString(".minutes2", comment: "")

		rectangleView3.layer.cornerRadius = 10
		rectangleView3.layer.masksToBounds =  true
		rectangleView3.backgroundColor = UIColor.seafoam
		rectangleView3.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)


		rectangleView4.layer.cornerRadius = 10
		rectangleView4.layer.masksToBounds =  true
		rectangleView4.backgroundColor = UIColor.seafoam
		rectangleView4.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)


		minutesLabel3.textColor = UIColor.daisy
		minutesLabel3.numberOfLines = 0
		minutesLabel3.font = UIFont.textStyle3
		minutesLabel3.textAlignment = .center
		minutesLabel3.text = NSLocalizedString(".minutes3", comment: "")

		noTimeLimitLabel.textColor = UIColor.daisy
		noTimeLimitLabel.numberOfLines = 0
		noTimeLimitLabel.font = UIFont.textStyle3
		noTimeLimitLabel.textAlignment = .center
		noTimeLimitLabel.text = NSLocalizedString("no.time.limit", comment: "")



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

