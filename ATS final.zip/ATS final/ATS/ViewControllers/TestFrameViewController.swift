import UIKit

class TestFrameViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var _view2: UIView!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var vectorImageView: UIImageView!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension TestFrameViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		_view2.layer.cornerRadius = 22
		_view2.layer.masksToBounds =  true
		_view2.backgroundColor = UIColor.smoke
		_view2.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.1599999964237213,
		                    x: 4,
		                    y: 4,
		                    blur: 17,
		                    spread: 0)
		_view2.addShadow(color: UIColor(red:0.9166666865348816, green: 0.9166666865348816, blue: 0.9166666865348816, alpha: 1),
		                    alpha: 0.07999999821186066,
		                    x: -4,
		                    y: -4,
		                    blur: 17,
		                    spread: 0)


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)



		logoutButton.setImage(UIImage(named: "icons2") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

