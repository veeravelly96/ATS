import UIKit

extension UIColor {
	@nonobjc class var amethyst: UIColor {
		return UIColor(red: 83.0 / 255.0, green: 104.0 / 255.0, blue: 240.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var amethyst2: UIColor {
		return UIColor(red: 157.0 / 255.0, green: 87.0 / 255.0, blue: 213.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var black_16: UIColor {
		return UIColor(red: 0.0 / 255.0, green: 0.0 / 255.0, blue: 0.0 / 255.0, alpha: 0.16)
	}

	@nonobjc class var black_30: UIColor {
		return UIColor(red: 0.0 / 255.0, green: 0.0 / 255.0, blue: 0.0 / 255.0, alpha: 0.3)
	}

	@nonobjc class var cerulean: UIColor {
		return UIColor(red: 66.0 / 255.0, green: 164.0 / 255.0, blue: 255.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var cloud: UIColor {
		return UIColor(red: 196.0 / 255.0, green: 196.0 / 255.0, blue: 196.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var coin: UIColor {
		return UIColor(red: 151.0 / 255.0, green: 151.0 / 255.0, blue: 151.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var daisy: UIColor {
		return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var daisy_33: UIColor {
		return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.33)
	}

	@nonobjc class var daisy_82: UIColor {
		return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.82)
	}

	@nonobjc class var marigold: UIColor {
		return UIColor(red: 254.0 / 255.0, green: 171.0 / 255.0, blue: 0.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var peacock: UIColor {
		return UIColor(red: 9.0 / 255.0, green: 53.0 / 255.0, blue: 69.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var pebble_75: UIColor {
		return UIColor(red: 52.0 / 255.0, green: 48.0 / 255.0, blue: 48.0 / 255.0, alpha: 0.75)
	}

	@nonobjc class var salt_8: UIColor {
		return UIColor(red: 234.0 / 255.0, green: 234.0 / 255.0, blue: 234.0 / 255.0, alpha: 0.08)
	}

	@nonobjc class var seafoam: UIColor {
		return UIColor(red: 32.0 / 255.0, green: 223.0 / 255.0, blue: 127.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var slate: UIColor {
		return UIColor(red: 119.0 / 255.0, green: 131.0 / 255.0, blue: 143.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var smoke: UIColor {
		return UIColor(red: 79.0 / 255.0, green: 87.0 / 255.0, blue: 91.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var spruce: UIColor {
		return UIColor(red: 34.0 / 255.0, green: 73.0 / 255.0, blue: 87.0 / 255.0, alpha: 1.0)
	}

	@nonobjc class var strawberry: UIColor {
		return UIColor(red: 255.0 / 255.0, green: 49.0 / 255.0, blue: 49.0 / 255.0, alpha: 1.0)
	}

}
