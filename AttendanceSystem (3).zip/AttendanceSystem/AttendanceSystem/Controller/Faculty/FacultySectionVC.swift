//
//  FacultySectionVC.swift
//  AttendanceSystem
//
//  Created by Student on 02/09/2022.
//

import UIKit

class FacultySectionVC: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
}
