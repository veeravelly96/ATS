//
//  GenerateQRVC.swift
//  AttendanceSystem
//
//  Created by Student on 06/09/2022.
//

import UIKit

class GenerateQRVC: UIViewController {
    
    @IBOutlet weak var imageViewQRCode: UIImageView!
    
    var semester:Semester = .Fall
    var year = ""
    var subject: SubjectModel?
    var section:Section = .A
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        
        
        var dict = [String: Any]()
        dict["semester"] = semester.rawValue.description
        dict["year"] = year
        dict["section"] = section.rawValue.description
        dict["subject"] = subject?.id
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, d MMM yyyy h:mm:ss a"
        dateFormatter.locale = .current
        dict["date"] = dateFormatter.string(from: Date())
        dict["faculty"] = AppStateManager.shared.loggedInUser?.faculty?.id

        
        if let string = jsonToString(json: dict) {
            if let image = generateQRCode(from: string) {
                imageViewQRCode.image = image
            }
        }
        
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 10, y: 10)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        return nil
    }
    
    func jsonToString(json: Any) -> String?  {
        do {
            let data1 =  try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted) // first of all convert json to the data
            let convertedString = String(data: data1, encoding: String.Encoding.utf8) // the data will be converted to the string
            print(convertedString ?? "defaultvalue")
            return convertedString
        } catch let myJSONError {
            print(myJSONError)
            return nil
        }
        
    }
    
}
