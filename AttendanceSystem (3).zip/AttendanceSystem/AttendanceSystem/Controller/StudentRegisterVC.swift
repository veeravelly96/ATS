//
//  StudentRegisterVC.swift
//  AttendanceSystem
//
//  Created by Student on 02/09/2022.
//

import UIKit
import FirebaseDatabase
import IQKeyboardManagerSwift

class StudentRegisterVC: UIViewController {
    
    @IBOutlet weak var registerBtn: UIButton!
    
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var rollNumberTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var semesterTF: UITextField!
    @IBOutlet weak var yearTF: UITextField!

    
    private let ref = Database.database().reference()
    private let dbPath = "student"
    
    let semesterPickerData = [String](arrayLiteral: "Fall", "Spring")
    var selctedSemester:Semester = .Fall
    
    let yearPickerData = [String](arrayLiteral: "2022", "2023", "2024")

    var selctedSubjectIds = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        nameTF.setTextField()
        emailTF.setTextField()
        rollNumberTF.setTextField()
        passwordTF.setTextField()
        semesterTF.setTextField()
        yearTF.setTextField()
        
        self.navigationItem.title = "Student"
        registerBtn.RoundCorners(radius: 8)
        
        semesterTF.delegate = self
        yearTF.delegate = self
        
        semesterTF.keyboardToolbar.doneBarButton.setTarget(self, action: #selector(semesterTFDoneButtonClicked))
        yearTF.keyboardToolbar.doneBarButton.setTarget(self, action: #selector(yearTFDoneButtonClicked))

    }
    
    
    @objc func semesterTFDoneButtonClicked(_ sender: Any) {
        let selectedRow = (semesterTF.inputView as? UIPickerView)?.selectedRow(inComponent: 0)
        semesterTF.text = semesterPickerData[selectedRow ?? 0]
        selctedSemester = Semester.init(rawValue: selectedRow ?? 0) ?? .Fall
    }
    
    @objc func yearTFDoneButtonClicked(_ sender: Any) {
        let selectedRow = (yearTF.inputView as? UIPickerView)?.selectedRow(inComponent: 0)
        yearTF.text = yearPickerData[selectedRow ?? 0]
    }
    
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        
        validateData()
    }
    
    func validateData() {
        
        var shouldProceed = true
        var message = ""
        
        if (nameTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please enter your name"
        }else if (rollNumberTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please enter your registration number"
        }else if (semesterTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please select your semester"
        }else if (yearTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please select your year"
        }else if (emailTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please enter your email"
        }else if !Utility.isValidEmail(testStr: emailTF.text!){
            shouldProceed = false
            message = "Please provide valid email address"
        }else if !isValidStudentEmail(emailTF.text ?? "") {
            shouldProceed = false
            message = "Please provide valid email address"
        }else if (passwordTF.text?.isEmpty)! {
            shouldProceed = false
            message = "Please enter your password"
        }
        
        if shouldProceed {
           registerStudent()
        }
        else {
            Utility.showAlert(title: "Error", message: message)
        }
    }
    
    func isValidStudentEmail(_ email: String) -> Bool {
        let emailPattern = #"s\S+@nwmissouri.edu"#
        let result = email.lowercased().range(
            of: emailPattern,
            options: .regularExpression
        )

        let validEmail = (result != nil)
        return validEmail
    }
    
    func registerStudent() {
        guard let autoId = ref.child(dbPath).childByAutoId().key else {
            return
        }
        
        let student = StudentModel.init(id: autoId, name: nameTF.text!, rollNumber: rollNumberTF.text!, email: emailTF.text!, password: passwordTF.text!, semester: selctedSemester, year: yearTF.text!)
        
        do {
            let data = try JSONEncoder().encode(student)
            
            let json = try JSONSerialization.jsonObject(with: data)
            
            ref.child("\(dbPath)/\(autoId)")
                .setValue(json)
            
            Utility.showAlert(title: "Alerty", message: "Student registered successfully", okTapped: {
//                let loggedInUser = UserModel.init(student: student, faculty: nil)
//                AppStateManager.shared.isUserLoggedIn = true
//                AppStateManager.shared.loggedInUser = loggedInUser
//                AppStateManager.shared.userRole = .Student
//
//                let VC = self.storyboard?.instantiateViewController(withIdentifier: "StudentHomeVC") as! StudentHomeVC
//
//                let window = UIApplication.shared.windows.first
//
//                // Embed loginVC in Navigation Controller and assign the Navigation Controller as windows root
//                let nav = UINavigationController(rootViewController: VC)
//                window?.rootViewController = nav
                self.navigationController?.popViewController(animated: true)
            })
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
}

extension StudentRegisterVC: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == semesterTF {
            let thePicker = UIPickerView()
            thePicker.delegate = self
            thePicker.tag = 1
            semesterTF.inputView = thePicker
            if !(textField.text?.isEmpty ?? true) {
                if let selectedIndex = semesterPickerData.firstIndex(where: { $0 == textField.text })  {
                    thePicker.selectRow(selectedIndex, inComponent: 0, animated: true)
                    pickerView(thePicker, didSelectRow: selectedIndex, inComponent: 0)
                }
            }
        }
        else if textField == yearTF {
            let thePicker = UIPickerView()
            thePicker.delegate = self
            thePicker.tag = 2
            yearTF.inputView = thePicker
            if !(textField.text?.isEmpty ?? true) {
                if let selectedIndex = yearPickerData.firstIndex(where: { $0 == textField.text })  {
                    thePicker.selectRow(selectedIndex, inComponent: 0, animated: true)
                    pickerView(thePicker, didSelectRow: selectedIndex, inComponent: 0)
                }
            }
        }
    }

}

extension StudentRegisterVC: UIPickerViewDelegate, UIPickerViewDataSource  {
    // MARK: UIPickerView Delegation
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView.tag == 1 {
            return semesterPickerData.count
        }
        else {
            return yearPickerData.count
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView.tag == 1 {
            return semesterPickerData[row]
        }
        else {
            return yearPickerData[row]
        }
        
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.tag == 1 {
            semesterTF.text = semesterPickerData[row]
            selctedSemester = Semester.init(rawValue: row) ?? .Fall
        }
        else {
            yearTF.text = yearPickerData[row]
        }
    }
}
