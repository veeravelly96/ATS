import UIKit

class TimeslotcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var timeSlotsLabel: UILabel!
	@IBOutlet private weak var line1ImageView: UIImageView!
	@IBOutlet private weak var rectangleView: UIView!
	@IBOutlet private weak var borderView: UIView!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension TimeslotcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		logoutButton.setImage(UIImage(named: "icons") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)

		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultycoursesselectioncontroller), for: .touchUpInside)

		timeSlotsLabel.textColor = UIColor.daisy
		timeSlotsLabel.numberOfLines = 0
		timeSlotsLabel.font = UIFont.textStyle6
		timeSlotsLabel.textAlignment = .center
		timeSlotsLabel.text = NSLocalizedString("time.slots", comment: "")


		rectangleView.layer.cornerRadius = 10
		rectangleView.layer.masksToBounds =  true
		rectangleView.backgroundColor = UIColor.spruce


		borderView.layer.borderColor = UIColor.cerulean.cgColor
		borderView.layer.borderWidth =  1
		borderView.layer.cornerRadius = 8
		borderView.layer.masksToBounds =  true




	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

