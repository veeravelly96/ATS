import UIKit

protocol Coordinator {
	var childCoordinators: [Coordinator] { get set }
	var navigationController: UINavigationController { get set }

	func start()
}

class MainCoordinator: Coordinator {
	var childCoordinators = [Coordinator]()
	var navigationController: UINavigationController

	init(navigationController: UINavigationController) {
		self.navigationController = navigationController
	}

	func start() {
		let vc = HomepagecontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: false)
	}

	@objc func openFacultyselectioncontroller() {
		let vc = FacultyselectioncontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openLogout() {
		let vc = LogoutViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openHomepagecontroller() {
		let vc = HomepagecontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openLoginfacultycontroller() {
		let vc = LoginfacultycontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openSignupfacultycontroller() {
		let vc = SignupfacultycontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openFacultycoursesselectioncontroller() {
		let vc = FacultycoursesselectioncontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openFacultyreportcontroller() {
		let vc = FacultyreportcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openFacultyhomepagecontroller() {
		let vc = FacultyhomepagecontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openStudenthomepagecontroller() {
		let vc = StudenthomepagecontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openQrcontroller() {
		let vc = QrcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openStudentreportcontroller() {
		let vc = StudentreportcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openCameracontroller() {
		let vc = CameracontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openStudentselectioncontroller() {
		let vc = StudentselectioncontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openLoginstudentcontroller() {
		let vc = LoginstudentcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openSignupstudentcontroller() {
		let vc = SignupstudentcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openRegistration() {
		let vc = RegistrationViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openTimeslotcontroller() {
		let vc = TimeslotcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

	@objc func openTimelimitcontroller() {
		let vc = TimelimitcontrollerViewController.instantiate()
		vc.coordinator = self
		navigationController.pushViewController(vc, animated: true)
	}

}