import UIKit

extension UIFont {
	class var textStyle: UIFont {
		return UIFont(name: "Montserrat-Medium", size: 14.0) ?? UIFont.systemFont(ofSize: 14.0)
	}

	class var textStyle10: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 43.0) ?? UIFont.systemFont(ofSize: 43.0)
	}

	class var textStyle2: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 16.0) ?? UIFont.systemFont(ofSize: 16.0)
	}

	class var textStyle3: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 14.0) ?? UIFont.systemFont(ofSize: 14.0)
	}

	class var textStyle4: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 64.0) ?? UIFont.systemFont(ofSize: 64.0)
	}

	class var textStyle5: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 50.0) ?? UIFont.systemFont(ofSize: 50.0)
	}

	class var textStyle6: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 45.0) ?? UIFont.systemFont(ofSize: 45.0)
	}

	class var textStyle7: UIFont {
		return UIFont(name: "Montserrat-Medium", size: 25.0) ?? UIFont.systemFont(ofSize: 25.0)
	}

	class var textStyle8: UIFont {
		return UIFont(name: "Montserrat-SemiBold", size: 14.0) ?? UIFont.systemFont(ofSize: 14.0)
	}

	class var textStyle9: UIFont {
		return UIFont(name: "LexendDeca-Regular", size: 40.0) ?? UIFont.systemFont(ofSize: 40.0)
	}

}
