//
//  AttendanceChartVC.swift
//  AttendanceSystem
//
//  Created by Student on 09/09/2022.
//

import UIKit
import FLCharts
import FirebaseDatabase


class AttendanceChartVC: UIViewController {
    
    @IBOutlet var cardView: FLCard!
    
    @IBOutlet var segmentedControl: UISegmentedControl!
    @IBOutlet var dateTFView: UIView!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var studentsTableView: UITableView!
    @IBOutlet weak var noRecordFoundLabel: UILabel!
    
    var userType = AppStateManager.shared.userRole
            
    var allAttendanceData = [AttendanceModel]()
    var filteredAttendanceData = [AttendanceModel]()
    
    var studentId = ""
    var semester:Semester = AppStateManager.shared.loggedInUser?.student?.semester ?? .Fall
    var section:Section = .A
    var subjectId = ""
    var year = "2022"
    
    var checkAttendanceByDate = false
    var selectedDateString = ""
    var selectedTabIndex = 0
    
    private lazy var databasePath: DatabaseReference? = {
        let ref = Database.database()
            .reference()
            .child("attendance")
        return ref
    }()
    
    private let decoder = JSONDecoder()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        
        if userType == .Student {
            
            self.navigationItem.title = "Student"
        }
        
        segmentedControl.isHidden = true
        dateTFView.isHidden = true
        studentsTableView.isHidden = true
        noRecordFoundLabel.isHidden = true
        
        if checkAttendanceByDate {
            
            dateTFView.RoundCorners(radius: 8)
            
            cardView.isHidden = true
            segmentedControl.isHidden = false
            dateTFView.isHidden = false
            studentsTableView.isHidden = false
            
            studentsTableView.delegate = self
            studentsTableView.dataSource = self

            dateTF.delegate = self
            dateTF.keyboardToolbar.doneBarButton.setTarget(self, action: #selector(dateTFDoneButtonClicked))
            
            dateTF.text = selectedDateString
            
            if selectedDateString == "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "d MMM yyyy"
                dateTF.text = dateFormatter.string(from: Date())
                selectedDateString = dateFormatter.string(from: Date())
            }
        }
        
        fetchAttendance()
    }
    
    @objc func dateTFDoneButtonClicked(_ sender: Any) {
        if let selectedDate = (dateTF.inputView as? UIDatePicker)?.date  {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "d MMM yyyy"
            dateTF.text = dateFormatter.string(from: selectedDate)
            selectedDateString = dateFormatter.string(from: selectedDate)
            
            fetchAttendance()
        }
    }
    
    @IBAction func indexChanged(_ sender: UISegmentedControl) {
        
        selectedTabIndex = segmentedControl.selectedSegmentIndex
        showStudentList()
    }
    
    func showStudentList() {
        
        self.filteredAttendanceData = allAttendanceData.filter({
            let dateString = $0.date ?? ""
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss Z"
            let date = dateFormatter.date(from:dateString) ?? Date()
            
            dateFormatter.dateFormat = "d MMM yyyy"
            let attendanceDate = dateFormatter.string(from: date)
            
            return (attendanceDate == self.selectedDateString)
        })
        
        switch selectedTabIndex {
        case 0:
            
            self.filteredAttendanceData = self.filteredAttendanceData.filter({
                return ($0.status == AttendanceStatus.Present)
            })
            
        case 1:
            
            self.filteredAttendanceData = self.filteredAttendanceData.filter({
                return ($0.status == AttendanceStatus.Absent)
            })
            
        default:
            
            self.filteredAttendanceData = self.filteredAttendanceData.filter({
                return ($0.status == AttendanceStatus.Late)
            })
        }
        
        studentsTableView.reloadData()
    }
    
    func fetchAttendance() {
        
        guard let databasePath = databasePath else {
            return
        }
        
        databasePath.getData(completion: {[weak self] error, snapshots in
            if error == nil {
                guard let self = self, let children = snapshots?.children.allObjects as? [DataSnapshot] else {
                    return
                }
                
                var allAttendance = children.compactMap { snapshot in
                    return AttendanceModel(snapshot: snapshot)
                }
                
                allAttendance = allAttendance.filter({
                    return (self.userType == .Student ? ($0.studentId == AppStateManager.shared.getStudentId()) : ($0.facultyId == AppStateManager.shared.getFacultyId()))
                })
                
                if self.studentId != "" {
                    self.filteredAttendanceData = allAttendance.filter({
                        return ($0.subjectId == self.subjectId && $0.section == self.section && $0.semester == self.semester && $0.studentId == self.studentId)
                    })
                }
                else {
                    
                    self.filteredAttendanceData = allAttendance.filter({
                        return ($0.subjectId == self.subjectId && $0.section == self.section && $0.semester == self.semester)
                    })
                    
                    if self.checkAttendanceByDate {
                        self.allAttendanceData = self.filteredAttendanceData
                        self.showStudentList()
                    }
                }
                
                let present = self.filteredAttendanceData.filter({
                    return ($0.status == AttendanceStatus.Present)
                })
                
                let absent = self.filteredAttendanceData.filter({
                    return ($0.status == AttendanceStatus.Absent)
                })
                
                let late = self.filteredAttendanceData.filter({
                    return ($0.status == AttendanceStatus.Late)
                })
                
                self.showAttendance(presentCount: CGFloat(present.count), lateCount: CGFloat(late.count), absentCount: CGFloat(absent.count))
            }
        })
        
    }
    
    func showAttendance(presentCount:CGFloat, lateCount:CGFloat, absentCount:CGFloat) -> Void {
        
        let data = [FLPiePlotable(value: presentCount, key: Key(key: "On Time", color: FLColor(hex: "008000"))),
                    FLPiePlotable(value: lateCount, key: Key(key: "Late", color: FLColor(hex: "00FF00"))),
                    FLPiePlotable(value: absentCount, key: Key(key: "Absent", color: FLColor(hex: "800000")))]
        //                    ,FLPiePlotable(value: 0.0, key: Key(key: "Leave", color: FLColor(hex: "FFFF00")))]
        
        let pieChart = FLPieChart(title: "Pie Chart",
                                  data: data,
                                  border: .full,
                                  formatter: .percent,
                                  animated: true)
        
        cardView.setup(chart: pieChart, style: .rounded)
        cardView.showAverage = false
        cardView.showLegend = true
        cardView.backgroundColor = .clear
    }
}

// MARK: - UItextField Delegate
extension AttendanceChartVC: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == dateTF {
            
            let datePickerView = UIDatePicker()
            datePickerView.datePickerMode = .date
            if #available(iOS 13.4, *) {
                datePickerView.preferredDatePickerStyle = .wheels
            } else {
                // Fallback on earlier versions
            }
            textField.inputView = datePickerView
        }
        
    }
}

extension AttendanceChartVC: UITableViewDelegate, UITableViewDataSource {
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        noRecordFoundLabel.isHidden = filteredAttendanceData.count != 0
        tableView.isHidden = filteredAttendanceData.count == 0
        
        return filteredAttendanceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "courseCell", for: indexPath) as! CourseTableViewCell
        cell.backgroundColor = .clear
        
        cell.imgView.isHidden = false
        
        cell.courseLbl.text = filteredAttendanceData[indexPath.row].studentName ?? ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

